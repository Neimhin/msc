zip -o code.zip src/* exp/*/*.sh
