python src/timing_plot.py -i exp/iibiii/all-time.csv:stride,exp/iic/all-time.csv:max-pool,exp/d/all-time.csv:extra-layers -o timing-comparison.pdf
