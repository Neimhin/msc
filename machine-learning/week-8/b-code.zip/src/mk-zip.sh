zip -o b-code.zip src/* exp/*/*.sh
