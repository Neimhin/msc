ps = [
        {"min": 1,              "max": 1024},           # minibatch
        {"min": 0.0000000001,   "max": 0.01},              # alpha
        {"min": 0.5,            "max": 1},              # beta1
        {"min": 0.5,            "max": 1},              # beta2
        {"min": 10,             "max": 100},            # epochs
]
